package com.myshop;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class ShopListener implements Listener {

    private final ShopPlugin plugin;

    public ShopListener(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;

        String invTitle = event.getView().getTitle();
        String name = clicked.getItemMeta().getDisplayName();

        if (invTitle.equals("Chest Shop")) {
            event.setCancelled(true);
            switch (name) {
                case "Blocks Shop":
                    plugin.getShopCommand().BlockShop(player);
                    break;
                case "Farming Shop":
                    player.sendMessage("Opening Farming Shop...");
                    break;
                case "Tools Shop":
                    player.sendMessage("Opening Tools Shop...");
                    break;
                case "Rebirth Shop":
                    player.sendMessage("Opening Rebirth Shop...");
                    break;
                case "Prestige Shop":
                    player.sendMessage("Opening Prestige Shop...");
                    break;
            }
        } else if (invTitle.equals("Blocks Shop")) {
            event.setCancelled(true);
            plugin.getShopCommand().handlePurchase(player, clicked);
        }
    }
}