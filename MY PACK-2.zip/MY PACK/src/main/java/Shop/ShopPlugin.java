package com.myshop;

import org.bukkit.plugin.java.JavaPlugin;

public class ShopPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        getLogger().info("Chest Shop Enabled!");
        this.getCommand("shop").setExecutor(new ShopCommand(this));
        getServer().getPluginManager().registerEvents(new ShopListener(this), this);
    }

    @Override
    public void onDisable() {
        getLogger().info("Chest Shop Disabled!");
    }
}