package com.myshop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.scoreboard.*;

import java.util.List;

public class ShopCommand implements CommandExecutor {

    private final ShopPlugin plugin;

    public ShopCommand(ShopPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        Inventory shop = Bukkit.createInventory(null, 27, "Chest Shop");
        shop.setItem(11, createButton(Material.GRASS_BLOCK, "Blocks Shop"));
        shop.setItem(12, createButton(Material.WHEAT, "Farming Shop"));
        shop.setItem(13, createButton(Material.IRON_PICKAXE, "Tools Shop"));
        shop.setItem(14, createButton(Material.NETHER_STAR, "Rebirth Shop"));
        shop.setItem(15, createButton(Material.DIAMOND_BLOCK, "Prestige Shop"));
        player.openInventory(shop);
        return true;
    }

    public void BlockShop(Player player) {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("blocks-shop");
        Inventory inv = Bukkit.createInventory(null, 54, "Blocks Shop");
        int slot = 0;
        for (String key : section.getKeys(false)) {
            Material mat = Material.matchMaterial(key);
            if (mat == null) continue;
            int price = section.getConfigurationSection(key).getInt("price");
            int amount = section.getConfigurationSection(key).getInt("amount");
            ItemStack item = new ItemStack(mat, amount);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(mat.name());
                meta.setLore(List.of("Price: $" + price, "Amount: " + amount));
                item.setItemMeta(meta);
            }
            inv.setItem(slot++, item);
        }
        player.openInventory(inv);
    }

    public void handlePurchase(Player player, ItemStack item) {
        if (item == null || !item.hasItemMeta()) return;
        String name = item.getType().name();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("blocks-shop");
        if (!section.contains(name)) return;
        int price = section.getConfigurationSection(name).getInt("price");
        int amount = section.getConfigurationSection(name).getInt("amount");
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        Objective obj = sb.getObjective("Money");
        if (obj == null) obj = sb.registerNewObjective("Money", "dummy", "Money");
        Score score = obj.getScore(player.getName());
        int balance = score.getScore();
        if (balance < price) {
            player.sendMessage("§cYou do not have enough Money!");
            return;
        }
        score.setScore(balance - price);
        player.getInventory().addItem(new ItemStack(item.getType(), amount));
        player.sendMessage("§aYou bought " + amount + " " + name + " for $" + price + "!");
    }

    private ItemStack createButton(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            item.setItemMeta(meta);
        }
        return item;
    }
}